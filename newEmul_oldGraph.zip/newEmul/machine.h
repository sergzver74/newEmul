#ifndef __MACHINE_H__
#define __MACHINE_H__

class Machine
{
public:
	Machine() {};
	~Machine() {};
	virtual void timer() = 0;
};


#endif // !__MACHINE_H__

