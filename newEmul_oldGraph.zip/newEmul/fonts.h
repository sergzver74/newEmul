#ifndef __FONTS_H__
#define __FONTS_H__

#define alHLEFT         0
#define alHCENTER       1
#define alHRIGHT        2
#define alVTOP          0
#define alVCENTER       1
#define alVBOTTOM       2


int length(char *c);
void setPhisicalScreen();
void restoreVirtualScreen();
void printxy(int x, int y, char* text);
int getLenTextInPixels(char* c, int size);
void setFontParam(int fid, unsigned int col, int scale,char halign, char valign);
int setFont(char *name, int sz, unsigned int col, char halign, char valign);
bool fontRegistred(char *name, int sz);
unsigned char registerNewFont(char* name);
void fontinit(unsigned char n);
void closefont();

#endif
