#ifndef __CPU_H__
#define __CPU_H__

class CPU
{
public:
	CPU() {};
	~CPU() {};
	virtual void reset() = 0;
};


#endif // !__CPU_H__
