/**
*  @headerfile	graph.h
*/

#include <stdint.h>

#ifndef __GRAPH_H__
#define __GRAPH_H__

// colors
#define cBLACK          RGBtoColor(0x00,0x00,0x00)          ///< черный цвет
#define cBLUE	        RGBtoColor(0x00,0x00,0x7F)          ///< синий цвет
#define cLIGHTBLUE      RGBtoColor(0x00,0x00,0xFF)          ///< светло-синий цвет
#define cGREEN          RGBtoColor(0x00,0x7F,0x00)          ///< зеленый цвет
#define cLIGHTGREEN     RGBtoColor(0x00,0xFF,0x00)          ///< светло-зеленый цвет
#define cRED            RGBtoColor(0x7F,0x00,0x00)          ///< красный цвет
#define cLIGHTRED       RGBtoColor(0xFF,0x00,0x00)          ///< светло-красный цвет
#define cDARKGRAY       RGBtoColor(0x18,0x1C,0x18)          ///< серый цвет
#define cGRAY           RGBtoColor(0x1C,0x3C,0x38)          ///< темно-серый цвет
#define cLIGHTGRAY      RGBtoColor(0x78,0x7C,0x78)          ///< светло-серый цвет
#define cWHITE          RGBtoColor(0xFF,0xFF,0xFF)          ///< белый цвет
#define cCYAN           RGBtoColor(0x00,0xFF,0xFF)          ///< бирюзовый цвет
#define cYELLOW         RGBtoColor(0xFF,0xFF,0x00)          ///< желтый цвет
#define cLIGHTMAGENTA   RGBtoColor(0xFF,0x00,0xFF)          ///< светло-фиолетовый цвет
#define cMAGENTA        RGBtoColor(0x7F,0x00,0x7F)          ///< фиолетовый цвет
#define cBROWN          RGBtoColor(0x7F,0x7F,0x00)          ///< коричневый цвет
#define cORANGE         RGBtoColor(0xFF,0x7F,0x00)          ///< оранжевый цвет
#define cWINGRAY        RGBtoColor(0x80,0x80,0x80)          ///< темно-серый цвет
#define cWINLIGHTGRAY   RGBtoColor(0xD4,0xD0,0xC8)          ///< светло-серый цвет
#define cWINDARKGRAY    RGBtoColor(0x40,0x40,0x40)          ///< серый цвет

// orientation
#define oVERTICAL       0           ///< вертикальная ориентация
#define oHORIZONTAL     1           ///< горизонтальная ориентация

#define arcRIGHTDOWN    0           ///< скругление правого нижнего угла
#define arcRIGHTUP      1           ///< скругление правого верхнего угла
#define arcLEFTDOWN     2           ///< скругление левого нижнего угла
#define arcLEFTUP       3           ///< скругление левого верхнего угла


typedef void (*PP)( int, int, unsigned int );
typedef unsigned int (*GP)(int x, int y);
typedef void (*CLSCR)();
typedef unsigned int (*RGBTOCOLOR)(unsigned int r, unsigned int g, unsigned int b);
typedef void (*COLORTORGB)(unsigned int col, unsigned int* r, unsigned int* g, unsigned int* b);
typedef void (*GBAR)(int x1, int y1, int x2, int y2);
typedef void (*GBARGR)(int x1, int y1, int x2, int y2, int orient, unsigned int col1, unsigned int col2);
typedef void (*FGRADIENT)(int xn,int yn, int x, int y, int x1, int y1, int orient, unsigned int col1, unsigned int col2);
typedef unsigned int* (*GIMG)(int x1,int y1,int x2,int y2);
typedef void (*PIMG)(int x1, int y1, unsigned int* imb);

/**
*@fn void moveAxis(int x, int y);
*@brief Функция переносит начало координат в точку с координатами (x,y)
*@param x координата по оси X
*@param y координата по оси Y
*/
void moveAxis(int x, int y);

/**
*@fn int getmaxx()
*@brief Функция возвращает максимально возможную координату по оси X.
*@return возвращает максимально возможную координату по оси X.
*/
int getmaxx();

/**
*@fn int getmaxy()
*@brief Функция возвращает максимально возможную координату по оси Y.
*@return возвращает максимально возможную координату по оси Y.
*/
int getmaxy();

/**
*@fn unsigned short RGBtoColor(unsigned short r, unsigned short g, unsigned short b);
*@brief Функция рассчитывает цвет по его компонентам.\n
*@details определяет отображаемый 16-битный цвет по составляющим красного, зеленого и синего цветов.
*@param r компонента красного цвета
*@param g компонента зеленого цвета
*@param b компонента синего цвета
*@return возвращает 16-битный цвет.
*/
extern RGBTOCOLOR RGBtoColor;

/**
*@fn void ColortoRGB(unsigned short col, unsigned short* r, unsigned short* g, unsigned short* b);
*@brief Функция рассчитывает цветовые компоненты по заданному цвету.\n
*@details определяет составляющие красного, зеленого и синего цветов в заданном 16-битном цвете.
*@param col 16-битный цвет
*@param r компонента красного цвета
*@param g компонента зеленого цвета
*@param b компонента синего цвета
*/
extern COLORTORGB ColortoRGB;

/**
*@fn void SetColor(unsigned short col);
*@brief Функция устанавливает цвет рисования.\n
*@details устанавливает цвет, которым будут выводиться линии, прямоугольники, окружности и дуги.
*@param col 16-битный цвет
*/
void SetColor(unsigned int col);

/**
*@fn void SetFillColor(unsigned short col);
*@brief Функция устанавливает цвет заливки прямоугольника.
*@param col 16-битный цвет
*/
void SetFillColor(unsigned int col);

/**
*@fn unsigned short GetColor();
*@brief Функция возвращает текущий цвет рисования.
*@return 16-битный цвет
*/
unsigned int GetColor();

/**
*@fn void putpixel(int x, int y, unsigned short col);
*@brief Функция устанавливает точку заданного цвета по заданным координатам.
*@param x координата по оси X
*@param y координата по оси Y
*@param col 16-битный цвет
*/
//void putpixel(int x, int y, unsigned int col);
extern PP putpixel;

/**
*@fn unsigned short getpixel (int x, int y);
*@brief Функция возвращает цвет точки находящейся по заданным координатам.
*@param x координата по оси X
*@param y координата по оси Y
*@return 16-битный цвет
*/
extern GP getpixel;

/**
*@fn void line(int x1, int y1, int x2, int y2);
*@brief Функция рисует линию от точки с координатами (x1,y1) до точки с координатами (x2,y2).
*@param x1 начальная координата по оси X
*@param y1 начальная координата по оси Y
*@param x2 конечная координата по оси X
*@param y2 конечная координата по оси Y
*/
void line(int x1, int y1, int x2, int y2);

/**
*@fn void rectangle(int x1, int y1, int x2, int y2);
*@brief Функция рисует прямоугольник от точки с координатами (x1,y1) до точки с координатами (x2,y2).
*@param x1 начальная координата по оси X
*@param y1 начальная координата по оси Y
*@param x2 конечная координата по оси X
*@param y2 конечная координата по оси Y
*/
void rectangle(int x1, int y1, int x2, int y2);

/**
*@fn void bar (int x1, int y1, int x2, int y2);
*@brief Функция рисует закрашенный прямоугольник от точки с координатами (x1,y1) до точки с координатами (x2,y2).
*@param x1 начальная координата по оси X
*@param y1 начальная координата по оси Y
*@param x2 конечная координата по оси X
*@param y2 конечная координата по оси Y
*/
extern GBAR bar;

/**
*@fn void Circle(int x0, int y0, int radius);
*@brief Функция рисует окружность.
*@param x0 координата центра по оси X
*@param y0 координата центра по оси Y
*@param radius радиус окружности
*/
void Circle(int x0, int y0, int radius);

/**
*@fn void arc(int x0, int y0, int radius, int part);
*@brief Функция рисует четверть окружности в заданном квадранте.
*@param x0 координата центра по оси X
*@param y0 координата центра по оси Y
*@param radius радиус окружности
*@param part указывает какую четверть окружности нарисовать\n
arcRIGHTDOWN  или  0 правая нижняя\n
arcRIGHTUP    или  1 правая верхняя\n
arcLEFTDOWN   или  2 левая нижняя\n
arcLEFTUP     или  3 левая верхняя\n
*/
void arc(int x0, int y0, int radius, int part);

/**
*@fn void bargradient (int x1, int y1, int x2, int y2, int orient, unsigned short col1, unsigned short col2);
*@brief Функция рисует прямоугольник закрашенный градиентной заливкой от точки с координатами (x1,y1) до точки с координатами (x2,y2).
*@param x1 начальная координата по оси X
*@param y1 начальная координата по оси Y
*@param x2 конечная координата по оси X
*@param y2 конечная координата по оси Y
*@param orient ориентация градиентной заливки\n
oVERTICAL     или  0 вертикальная\n
oHORIZONTAL   или  1 горизонтальная
*@param col1 начальный цвет градиентной заливки
*@param col2 конечный цвет градиентной заливки
*/
extern GBARGR bargradient;

/**
*@fn void fillgradient(int xn,int yn, int x, int y, int x1, int y1, int orient, unsigned short col1, unsigned short col2);
*@brief Функция закрашивает градиентной заливкой от точки с координатами (xn,yn) до границы нарисованной текущим цветом, но не больше, чем прямоугольник от точки с координатами (x,y) до точки с координатами (x1,y1).
*@param xn начальная координата заливки по оси X
*@param yn начальная координата заливки по оси Y
*@param x начальная координата по оси X
*@param y начальная координата по оси Y
*@param x1 конечная координата по оси X
*@param y1 конечная координата по оси Y
*@param orient ориентация градиентной заливки\n
oVERTICAL     или  0 вертикальная\n
oHORIZONTAL   или  1 горизонтальная
*@param col1 начальный цвет градиентной заливки
*@param col2 конечный цвет градиентной заливки
*/
extern FGRADIENT fillgradient;

/**
*@fn void roundrect(int x, int y, int x1, int y1, int radius);
*@brief Функция рисует прямоугольник со скругленными вершинами от точки с координатами (x,y) до точки с координатами (x1,y1).
*@param x начальная координата по оси X
*@param y начальная координата по оси Y
*@param x1 конечная координата по оси X
*@param y1 конечная координата по оси Y
*@param radius радиус скругления вершин
*/
void roundrect(int x, int y, int x1, int y1, int radius);

/**
*@fn void roundrectgradient(int x, int y, int x1, int y1, int radius, int orient, unsigned short col1, unsigned short col2);
*@brief Функция рисует прямоугольник со скругленными вершинами от точки с координатами (x,y) до точки с координатами (x1,y1) и градиентной заливкой
*@param x начальная координата по оси X
*@param y начальная координата по оси Y
*@param x1 конечная координата по оси X
*@param y1 конечная координата по оси Y
*@param radius радиус скругления вершин
*@param orient ориентация градиентной заливки\n
oVERTICAL     или  0 вертикальная\n
oHORIZONTAL   или  1 горизонтальная
*@param col1 начальный цвет градиентной заливки
*@param col2 конечный цвет градиентной заливки
*/
void roundrectgradient(int x, int y, int x1, int y1, int radius, int orient, unsigned int col1, unsigned int col2);

/**
*@fn void circlegradient(int x, int y, int radius, int orient, unsigned short col1, unsigned short col2);
*@brief Функция рисует окружность с градиентной заливкой.
*@param x координата центра по оси X
*@param y координата центра по оси Y
*@param radius радиус окружности
*@param orient ориентация градиентной заливки\n
oVERTICAL     или  0 вертикальная\n
oHORIZONTAL   или  1 горизонтальная
*@param col1 начальный цвет градиентной заливки
*@param col2 конечный цвет градиентной заливки
*/
void circlegradient(int x, int y, int radius, int orient, unsigned int col1, unsigned int col2);

/**
*@fn void setAlpha(char a);
*@brief Функция устанавливает уровень прозрачности в процентах. Используется для вывода сохраненной области изображений.
*@param a уровень прозрачности.
*/
void setAlpha(char a);

/**
*@fn void setPutImageStyle(int type, unsigned int col);
*@brief Функция устанавливает параметры вывода сохраненной области изображения.
*@param type определяет способ вывода.\n
0 - вывод без изменений\n
1 - не выводить точки уазанного цвета
*@param col 16-битный цвет, который не будет выводиться, при type=1.
*/
void setPutImageStyle(int type, unsigned int col);

/**
*@fn unsigned short* getImage(int x1,int y1,int x2,int y2);
*@brief Функция сохраняет прямоугольную область изображения.
*@param x1 начальная координата по оси X
*@param y1 начальная координата по оси Y
*@param x2 конечная координата по оси X
*@param y2 конечная координата по оси Y
*@return указатель на сохраненную область
*/
extern GIMG getImage;

/**
*@fn void putImage(int x1, int y1, unsigned short* imb);
*@brief Функция выводит сохраненную область изображения начиная с указанных координат.
*@param x1 начальная координата по оси X
*@param y1 начальная координата по оси Y
*@param imb указатель на сохраненное изображение
*/
extern PIMG putImage;

/**
*@fn void freeImage(unsigned short* imb);
*@brief Функция освобождает сохраненную область изображения.
*@param imb указатель на сохраненное изображение
*/
void freeImage(unsigned int* imb);

/**
*@fn int initgr(unsigned char n);
*@brief Функция инициализирует работу с фреймбуфером.
*@param n порядковый номер фреймбуфера 0-3
*@return результат инициализации\n
0 - успешно\n
1 - отсутствует фреймбуфер\n
2 - ошибка получения параметров фреймбуфера\n
3 - ошибка выделения памяти
4 - ошибка: фреймбуфер уже инициализирован
*/
int initgr(void * fbPointer, uint16_t width, uint16_t heigth, uint8_t bps);

/**
*@fn void setOutputContext(int x,int y,int x1,int y1);
*@brief Функция устанавливает область вывода изображения.\n
*@details Если координаты изображения укладываются в указанную прямоугольную область, то изображение выводится. Участок изображения, который не помещается в указанную область будет отсечен.
*@param x начальная координата по оси X
*@param y начальная координата по оси Y
*@param x1 конечная координата по оси X
*@param y1 конечная координата по оси Y
*/
void setOutputContext(int x,int y,int x1,int y1);

/**
*@fn void clearScreen()
*@brief Функция очищает экран.
*/
//void clearScreen();
extern CLSCR clearScreen;

/**
*@fn void restoreDefaultContext();
*@brief Функция восстанавливает область вывода изображения на весь экран.
*/
void restoreDefaultContext();

/**
*@fn void getOutputContext(int *x, int *y, int *mx, int *my);
*@brief Функция возвращает координаты области вывода изображения.
*@param x начальная координата по оси X
*@param y начальная координата по оси Y
*@param mx конечная координата по оси X
*@param my конечная координата по оси Y
*/
void getOutputContext(int *x, int *y, int *mx, int *my);

/**
*@fn void setVirtualScreen(unsigned short *scr, int width, int height);
*@brief Функция переназначает графический вывод на указанный буфер.
*@param scr указатель на новый буфер экрана
*@param width ширина виртуального экрана
*@param height высота вируального экрана
*/
void setVirtualScreen(unsigned short *scr, int width, int height);

/**
*@fn void restoreOriginalScreen();
*@brief Функция восстанавливает параметры вывода во фреймбуффер
*/
void restoreOriginalScreen();

/**
*@fn void closegr();
*@brief Функция завершает работу с фреймбуфером.
*/
void closegr();

#endif
