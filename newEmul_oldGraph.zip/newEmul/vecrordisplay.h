#ifndef __VECTORDISPLAY_H__
#define __VECTORDISPLAY_H__

#include <SDL.h>
#include "i8080.h"

typedef struct
{
	unsigned char R, G, B;
} TPalette;

class VectorDisplay
{

public:
	VectorDisplay(SDL_Renderer* rendr, uint8_t* videomem, i8080 *c);
	~VectorDisplay();
	void syncDisplay();
	void reset();
	void SetPalette();

private:
	SDL_Renderer* renderer;
	uint8_t* videoMemory;
	i8080* cpu;

	uint8_t fline;
	uint8_t bcol1, bcol2, scol1, scol2;
	uint8_t ScreenPalette[16];
	TPalette PallTable[256];
	uint16_t SVP;
	uint8_t SGP;
	uint16_t SADDR;
	uint8_t port02;
	uint8_t port03;
	uint8_t port0C;

};

#endif // !__VECTORDISPLAY_H__
