#include <iostream>
#include "z80.h"

using namespace std;

void z80::reset() {
	cout << "THIS Z80 processor" << endl;
}