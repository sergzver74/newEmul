#ifndef __I8080_H__
#define __I8080_H__
#include "cpu.h"
#include "memory.h"
#include "emutypes.h"

typedef union {
	uint16_t r16;
	struct {
		uint8_t lo;
		uint8_t hi;
	} r8;
} i8080reg16;

class i8080 : public CPU
{
public:
	i8080(Memory* mem);
	~i8080();
	void reset();
	uint8_t execute();
	uint8_t execute(uint16_t addr);
	string dasm(uint16_t* addr);
	Registers getRegisters();
	uint8_t getPortData(uint8_t port);
	void setPortData(uint8_t port, uint8_t data);
	void interruptRequest();

private:
	uint8_t ports_in[256];
	uint8_t ports_out[256];
	uint16_t pc;
	uint16_t sp;
	i8080reg16 bc, de, hl;
	uint8_t a, fl;
	bool INTE, HLT;
	Memory *memory;
	uint64_t TickCount;

	void setfl();
	void summ(uint8_t sl, uint8_t ppp, uint8_t typ);
	uint8_t inrdcr(uint8_t sl, uint8_t typ);
};


#endif // !__I8080_H__
