#include "vecrordisplay.h"

void VectorDisplay::SetPalette()
{

	uint8_t RG[8] = { 0, 19, 26, 34, 41, 48, 55, 63 };
	uint8_t BL[4] = { 0, 31, 47, 63 };
	uint8_t B, G, R, k;

	for (B = 0; B < 4; B++)
	{
		for (G = 0; G < 8; G++)
		{
			for (R = 0; R < 8; R++)
			{
				k = B * 64 + G * 8 + R;
				PallTable[k].B = BL[B] * 4;
				PallTable[k].G = RG[G] * 4;
				PallTable[k].R = RG[R] * 4;
			}
		}
	}
}

VectorDisplay::VectorDisplay(SDL_Renderer* rendr, uint8_t *videomem, i8080* c) {
	renderer = rendr;
	videoMemory = videomem;
	cpu = c;
	SetPalette();
	for (int i = 0; i < 16; i++) ScreenPalette[i] = 0;
	SGP = 0;
	SVP = 0;
	SADDR = 0xE0FF;
}

VectorDisplay::~VectorDisplay() {

}

void VectorDisplay::reset() {
	//for (int i = 0; i < 16; i++) ScreenPalette[i] = 0;
	SGP = 0;
	SVP = 0;
	cpu->setPortData(0x02, 0xFF);
	cpu->setPortData(0x03, 0xFF);
	SADDR = 0xE0FF;
}

void VectorDisplay::syncDisplay() {
	
	bool result = false;
	uint16_t i;
	uint8_t p0, p1, p2, p3, b0, b1, b2, b3, col;

	uint8_t ports02 = cpu->getPortData(0x02);
	uint8_t ports03 = cpu->getPortData(0x03);
	uint8_t ports0C = cpu->getPortData(0x0C);

	if (ports02 != port02) {
		port02 = ports02;
	}
	if (ports03 != port03) {
		port03 = ports03;
	}
	if (ports0C != port0C) {
		port0C = ports0C;
		ScreenPalette[port02 & 0x0F] = port0C;
	}

	if (((ports02 >> 4) & 0x01) == 0)
	{
		bcol1 = ScreenPalette[ports02 & 0x0F];
		bcol2 = ScreenPalette[ports02 & 0x0F];
	}
	else
	{
		bcol1 = ScreenPalette[(ports02 & 0x0F) & 0x03];
		bcol2 = ScreenPalette[(ports02 & 0x0F) >> 2];
	}

	if (SVP < 16)
	{
		if (SGP < 40)
		{
			for (i = 0; i < 8; i++)
			{
				SDL_SetRenderDrawColor(renderer, PallTable[bcol1].R, PallTable[bcol1].G, PallTable[bcol1].B, 0xFF);
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2)), (586 - SVP * 2));
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2)), (586 - ((SVP * 2) + 1)));
				SDL_SetRenderDrawColor(renderer, PallTable[bcol2].R, PallTable[bcol2].G, PallTable[bcol2].B, 0xFF);
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2 + 1)), (586 - SVP * 2));
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2 + 1)), (586 - ((SVP * 2) + 1)));
			}
		}
	}

	if ((SVP >= 16) && (SVP < 272))
	{
		if (SGP < 4)
		{

			for (i = 0; i < 8; i++)
			{
				SDL_SetRenderDrawColor(renderer, PallTable[bcol1].R, PallTable[bcol1].G, PallTable[bcol1].B, 0xFF);
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2)), (586 - SVP * 2));
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2)), (586 - SVP * 2 + 1));
				SDL_SetRenderDrawColor(renderer, PallTable[bcol2].R, PallTable[bcol2].G, PallTable[bcol2].B, 0xFF);
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2 + 1)), (586 - SVP * 2));
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2 + 1)), (586 - SVP * 2 + 1));
			}
		}

		if ((SGP >= 4) && (SGP < 36))
		{
			fline = 255 - ports03;
			if (SVP + fline >= 272)
			{
				p0 = videoMemory[SADDR - fline + 0x100];
				p1 = videoMemory[SADDR - 0x2000 - fline + 0x100];
				p2 = videoMemory[SADDR - 0x4000 - fline + 0x100];
				p3 = videoMemory[SADDR - 0x6000 - fline + 0x100];
			}
			else
			{
				p0 = videoMemory[SADDR - fline];
				p1 = videoMemory[SADDR - 0x2000 - fline];
				p2 = videoMemory[SADDR - 0x4000 - fline];
				p3 = videoMemory[SADDR - 0x6000 - fline];
			}
			for (int i = 7; i >= 0; i--)
			{
				b0 = p0 & 0x01;
				p0 = p0 >> 1;
				b1 = p1 & 0x01;
				p1 = p1 >> 1;
				b2 = p2 & 0x01;
				p2 = p2 >> 1;
				b3 = p3 & 0x01;
				p3 = p3 >> 1;
				col = (b3 << 3) + (b2 << 2) + (b1 << 1) + b0;
				if (((ports02 >> 4) & 0x01) == 0)
				{
					scol1 = ScreenPalette[col];
					scol2 = ScreenPalette[col];
				}
				else
				{
					scol1 = ScreenPalette[col & 0x03];
					scol2 = ScreenPalette[(col >> 2) << 2];
				}
				SDL_SetRenderDrawColor(renderer, PallTable[scol1].R, PallTable[scol1].G, PallTable[scol1].B, 0xFF);
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2)), (586 - SVP * 2));
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2)), (586 - SVP * 2 + 1));
				SDL_SetRenderDrawColor(renderer, PallTable[scol2].R, PallTable[scol2].G, PallTable[scol2].B, 0xFF);
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2 + 1)), (586 - SVP * 2));
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2 + 1)), (586 - SVP * 2 + 1));
			}
			SADDR += 0x0100;
			if (SADDR < 0x0100)
			{
				SADDR -= 0x2001;
				if (SADDR == 0xDFFF) SADDR = 0xE0FF;
			}
		}

		if ((SGP >= 36) && (SGP < 40))
		{
			for (i = 0; i < 8; i++)
			{
				SDL_SetRenderDrawColor(renderer, PallTable[bcol1].R, PallTable[bcol1].G, PallTable[bcol1].B, 0xFF);
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2)), (586 - SVP * 2));
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2)), (586 - SVP * 2 + 1));
				SDL_SetRenderDrawColor(renderer, PallTable[bcol2].R, PallTable[bcol2].G, PallTable[bcol2].B, 0xFF);
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2 + 1)), (586 - SVP * 2));
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2 + 1)), (586 - SVP * 2 + 1));
			}
		}
	}
	if ((SVP >= 272) && (SVP < 288))
	{
		if (SGP < 40)
		{
			for (i = 0; i < 8; i++)
			{
				SDL_SetRenderDrawColor(renderer, PallTable[bcol1].R, PallTable[bcol1].G, PallTable[bcol1].B, 0xFF);
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2)), (586 - SVP * 2));
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2)), (586 - SVP * 2 + 1));
				SDL_SetRenderDrawColor(renderer, PallTable[bcol2].R, PallTable[bcol2].G, PallTable[bcol2].B, 0xFF);
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2 + 1)), (586 - SVP * 2));
				SDL_RenderDrawPoint(renderer, (SGP * 16 + (i * 2 + 1)), (586 - SVP * 2 + 1));
			}
		}
	}

	if ((SVP == 288) && (SGP == 0))
	{
		//SwapBuffers(st->dcWindow);
		SDL_RenderPresent(renderer);
		cpu->interruptRequest();
		//fprintf(st->dbgfile, "TickCount, %d", st->TickCount * st->TickTime / 3200000000);
		//result = true;
		/*
		if (st->INTE) //{ && !stopcpu }
		{
			st->HLT = false;
			st->INTE = false;
			st->sp--;
			setToStack(st, st->sp, st->pc >> 8);
			st->sp--;
			setToStack(st, st->sp, st->pc & 0xFF);
			st->pc = 56;
			st->NumTicks += 36;
		}
		*/
	}

	SGP++;
	if (SGP == 48)
	{
		SGP = 0;
		SVP++;
	}
	if (SVP == 312) SVP = 0;

	//return result;
}