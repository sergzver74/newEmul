#ifndef __EVENTS_H__
#define __EVENTS_H__

class Events
{
public:
	Events() {};
	~Events() {};

private:

};

#endif // !__EVENTS_H__
