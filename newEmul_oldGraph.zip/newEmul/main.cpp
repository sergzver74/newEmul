#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>

#include <SDL.h>
#include "vector06c.h"
#include "graph.h"
#include "fonts.h"
#include "gui.h"
#include "menu.h"
#include "doevents.h"

//long long clockCount = 0;

//void t3Mhz() {
//	clockCount++;
//}

//void newCPU(CPU *cp) {
//	cp->reset();
//}

bool exitProgramm = false;
SDL_Window* subWindow;
SDL_Renderer* subRenderer;

void openRom() {
	printf("Selected OpenROM\n");

	subWindow = SDL_CreateWindow("Open ROM", 100, 100, 200, 200, 0);
	subRenderer = SDL_CreateRenderer(subWindow, -1, SDL_RENDERER_ACCELERATED);
	SDL_SetRenderDrawColor(subRenderer, 0, 255, 0, 255);
	SDL_RenderClear(subRenderer);
	SDL_RenderPresent(subRenderer);
}

void openWav() {
	printf("Selected openWav\n");
}

void exitRun() {
	printf("Selected exitRun\n");
	exitProgramm = true;
}

void debugger() {
	printf("Selected debugger\n");
}

void options() {
	printf("Selected options\n");
}

const int SCREEN_WIDTH = 640;
const int SCREEN_HEIGHT = 640;

int main(int argc, char* args[]) {
	
	printf("Start\n");

	exitProgramm = false;
	initEvents();

	SDL_Event event;
	SDL_Renderer* renderer;
	SDL_Window* window;
	int i;

	SDL_Init(SDL_INIT_VIDEO);
	SDL_CreateWindowAndRenderer(SCREEN_WIDTH, SCREEN_HEIGHT, 0, &window, &renderer);
	
	
	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
	SDL_RenderClear(renderer);
	//SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
	//for (i = 0; i < 100; ++i)
		//SDL_RenderDrawPoint(renderer, i, i);
	//SDL_RenderPresent(renderer);
	
	SDL_Surface* surf = NULL;
	SDL_Texture* tex = NULL;

//create destination rectangle
	SDL_Rect destr;
	destr.x = 0;
	destr.y = 0;
	surf = SDL_CreateRGBSurface(0, SCREEN_WIDTH, SCREEN_HEIGHT, 32, 0, 0, 0, 0);

	int rs = initgr((void*)surf->pixels,surf->w,surf->h, surf->format->BitsPerPixel);
	fontinit(0);
	registerNewFont((char*)"sserifer.fon");
	
	SetFillColor(cLIGHTGRAY);
	//bar(100, 100, 600, 600);
	bargradient(100, 100, 600, 600, 1, cGREEN, cRED);

	menu *mainMenu = new menu;
	mainMenu->create(0, 0, 639, 25);
	mainMenu->addMainMenuItem("File");
	mainMenu->addSubMenuItem(0, "Open ROM...", openRom);
	mainMenu->addSubMenuItem(0, "Open WAVE...", openWav);
	mainMenu->addSubMenuItem(0, "Exit", exitRun);
	mainMenu->addMainMenuItem("Debug");
	mainMenu->addSubMenuItem(1, "Debugger", debugger);
	mainMenu->addMainMenuItem("Settings");
	mainMenu->addSubMenuItem(2, "Options", options);
	mainMenu->Visibled(true);

	//tLabel label1;
	//label1.create(200, 200, 300, 240, cBLACK, "File");
	//label1.setparam(2, 1, 0, 0, 0);
	//label1.Visibled(true);

	tex = SDL_CreateTextureFromSurface(renderer, surf);

	if ((SDL_RenderCopy(renderer, tex, NULL, NULL)) < 0) {
		printf("%s\n", SDL_GetError());
		exit(-1);
	}

	SDL_RenderPresent(renderer);
	//Sleep(2000);
	

	//SetColor(cRED);
	//line(10, 10, 600, 600);

	//tex = SDL_CreateTextureFromSurface(renderer, surf);

	//if ((SDL_RenderCopy(renderer, tex, NULL, NULL)) < 0) {
		//printf("%s\n",SDL_GetError());
		//exit(-1);
	//}

	//SDL_RenderPresent(renderer);

	//Vector06c vector(renderer);
	//vector.start();
	
	/*
	SDL_Window* subWindow  = SDL_CreateWindow( "Sub Window" , subPosX, subPosY, subSizeX, subSizeY, 0 );
    SDL_Renderer* subRenderer  = SDL_CreateRenderer( subWindow, -1, SDL_RENDERER_ACCELERATED );
    SDL_SetRenderDrawColor( subRenderer , 0, 255, 0, 255 );
	*/
	
	
	bool eventRes = false;
	while (1) {
		if (SDL_PollEvent(&event) != 0) {
			if (event.type == SDL_QUIT)	break;
			if (event.type == SDL_MOUSEMOTION) {
				int x, y;
				SDL_GetMouseState(&x, &y);
				eventRes = checkDoEvent(MOUSEMOVE, x, y);
				//printf("(%d,%d) ", x, y);
			}
			if (event.type == SDL_MOUSEBUTTONDOWN) {
				if (event.button.button == SDL_BUTTON_LEFT) {
					int x, y;
					SDL_GetMouseState(&x, &y);
					//printf("Left button down on (%d,%d) ", x, y);
					eventRes = checkDoEvent(MOUSELEFTBUTTONDOWN, x, y);
				}
			}
			if (event.type == SDL_MOUSEBUTTONUP) {
				if (event.button.button == SDL_BUTTON_LEFT) {
					int x, y;
					SDL_GetMouseState(&x, &y);
					//printf("Left button down on (%d,%d) ", x, y);
					eventRes = checkDoEvent(MOUSELEFTBUTTONUP, x, y);
				}
			}
			if (event.type == SDL_WINDOWEVENT) {
				if (event.window.event == SDL_WINDOWEVENT_CLOSE) {
					printf("Window %d closed\n", event.window.windowID);
					if (event.window.windowID != 1) SDL_DestroyWindow(SDL_GetWindowFromID(event.window.windowID));
				}
			}
		}
		if (eventRes) {
			eventRes = false;
			tex = SDL_CreateTextureFromSurface(renderer, surf);

			if ((SDL_RenderCopy(renderer, tex, NULL, NULL)) < 0) {
				printf("%s\n", SDL_GetError());
				exit(-1);
			}

			SDL_RenderPresent(renderer);
		}
		if (exitProgramm) break;
	}

	printf("\n");

	//Vector06c vector;
	
	//i8080 cpu;
	//newCPU(&cpu);

	/*
	clockCount = 0;
	
	Timer timer(3000000);
	timer.start(t3Mhz,true);

	for (int i = 0; i < 30; i++) {
		Sleep(1000);
		long long clCount = clockCount;
		clockCount = 0;
		printf("Current clock: %lld Hz\n", clCount);
	}
	timer.stop();
	*/
	//screen_surface = SDL_GetWindowSurface(window);

	//SDL_FillRect(screen_surface, NULL, SDL_MapRGB(screen_surface->format, 0, 255, 0));

	//SDL_UpdateWindowSurface(window);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	SDL_Quit();
	
	printf("End prog\n");

	return EXIT_SUCCESS;
}