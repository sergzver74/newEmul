#include "graph.h"
#include "fonts.h"
#include "gui.h"

void tLabel::outText() {
    if (bkexists)
    {
        switch (bktp)
        {
        case tBkRect:
            SetFillColor(bkcolor);
            bar(lx,ly, lx1, ly1);
            break;
        case tBkRoundRect:
            SetColor(bkcolor);
            roundrectgradient(lx, ly, lx1, ly1, 10, oHORIZONTAL, bkcolor, bkcolor);
            break;
        case tBkCircle:

            break;
        default:
            break;
        }
    }
    setOutputContext(lx - 1, ly - 1, lx1, ly1);
    if (tp == tSHADOW)
    {
        setFontParam(fid, shcl, sz, lhl, lvl);
        printxy(lx + 1, ly + 1, (char*)txt.c_str());
    }
    if (tp == tBOLDSHADOW)
    {
        setFontParam(fid, shcl, sz, lhl, lvl);
        printxy(lx + 2, ly + 2, (char*)txt.c_str());
        printxy(lx + 2, ly + 3, (char*)txt.c_str());
        printxy(lx + 3, ly + 2, (char*)txt.c_str());
        printxy(lx + 3, ly + 3, (char*)txt.c_str());

    }
    setFontParam(fid, lcl, sz, lhl, lvl);
    printxy(lx, ly, (char*)txt.c_str());
    if (tp == tBOLD || tp == tBOLDSHADOW)
    {
        printxy(lx, ly + 1, (char*)txt.c_str());
        printxy(lx + 1, ly, (char*)txt.c_str());
        printxy(lx + 1, ly + 1, (char*)txt.c_str());
    }
    restoreDefaultContext();
}

void tLabel::create(int x, int y, int dx, int dy, unsigned int col, std::string text)
{
    lx = x;
    ly = y;
    lx1 = x + dx;
    ly1 = y + dy;
    fid = 0;
    sz = 1;
    tp = 0;
    lhl = 0;
    lvl = 0;
    lcl = col;
    bkexists = false;
    bkcolor = 0;
    shcl = 0;
    txt = text;
    visible = false;
    enable = true;
    lbl = NULL;
}

void tLabel::setparam(int fontid, int size, int type, char halign, char valign)
{
    fid = fontid;
    sz = size;
    tp = type;
    lhl = halign;
    lvl = valign;
}

void tLabel::setBkColor(unsigned int color)
{
    bkexists = true;
    bkcolor = color;
}

void tLabel::setBkType(char type)
{
    bktp = type;
}

void tLabel::setColor(unsigned int col)
{
    lcl = col;
}

void tLabel::setShadowColor(unsigned int col)
{
    shcl = col;
}

void tLabel::changeColor(uint32_t col) {
    if (lcl != col) {
        lcl = col;
        if (visible) {
            putImage(lx, ly, lbl);
            outText();
        }
    }
}

void tLabel::changecaption(std::string text)
{
    if (txt != text) {
        txt = text;
        if (visible) {
            putImage(lx, ly, lbl);
            outText();
        }
    }
}

void tLabel::Visibled(bool vis) {
    if (vis != visible) {
        visible = vis;
        if (!visible) {
            if (lbl != NULL) {
                putImage(lx, ly, lbl);
                freeImage(lbl);
                lbl = NULL;
            }
        }
        else {
            lbl = getImage(lx, ly, lx1, ly1);
            outText();
        }
    }
}

uint16_t tLabel::GetX() { return lx; }
uint16_t tLabel::GetX1() { return lx1; }
uint16_t tLabel::GetY() { return ly; }
uint16_t tLabel::GetY1() { return ly1; }

void tLabel::Enabled(bool en) {

}

void tLabel::Destroy()
{
    if (lbl != NULL)
    {
        putImage(lx, ly, lbl);
        freeImage(lbl);
        lbl = 0;
    }
    bkexists = false;
    bkcolor = 0;
    bktp = 0;
    fid = 0;
    sz = 0;
    tp = 0;
    shcl = 0;
    visible = false;
}

void tLabel::OnClick(uint32_t param1, uint32_t param2) {

}

void tLabel::OnClickUp(uint32_t param1, uint32_t param2) {

}

void tLabel::OnMove(uint32_t param1, uint32_t param2) {

}

void tLabel::OnEndMove(uint32_t param1, uint32_t param2) {

}

int tLabel::getLengthTextInPixels(int fontid, int size, std::string text) {
    setFontParam(fontid, 0, size, 0, 0);
    return getLenTextInPixels((char*)text.c_str(), size);
}