

#include "vector06c.h"
#include <Windows.h>


void Vector06c::recalculateToVector() {
	if (commandTicksCount == 4) return;
	if (commandTicksCount == 5) {
		commandTicksCount = 8;
		return;
	}
	if (commandTicksCount == 7) {
		commandTicksCount = 8;
		return;
	}
	if (commandTicksCount == 10) {
		commandTicksCount = 12;
		return;
	}
	if (commandTicksCount == 11) {
		commandTicksCount = 16;
		return;
	}
	if (commandTicksCount == 13) {
		commandTicksCount = 16;
		return;
	}
	if (commandTicksCount == 16) {
		commandTicksCount = 20;
		return;
	}
	if (commandTicksCount == 17) {
		commandTicksCount = 24;
		return;
	}
	if (commandTicksCount == 18) {
		commandTicksCount = 24;
		return;
	}
	printf("error timings for vector06c\n");
	exit(0);
}

void Vector06c::timer() {
	
	if (enabled) {
		clockCount++;
		if (!cycle) {
			cycle = true;
			commandTicksCount = cpu->execute();
			recalculateToVector();
		}
		if (cycle) {
			if ((tickCount & 0x03) == 0) {
				display->syncDisplay();
			}
			tickCount++;
			if (tickCount == commandTicksCount) {
				tickCount = 0;
				cycle = false;
			}
		}
	}
}

Vector06c::Vector06c() {

}

Vector06c::Vector06c(SDL_Renderer* rendr)
{
	renderer = rendr;
	enabled = false;
	clock = new Timer(3000000);
	mem = new Memory(65536, 5, 0, "d:\\boots.bin");
	cpu = new i8080(mem);
	uint8_t* vMem = NULL;
	vMem = mem->getVideoMemoryPointer(0x8000);
	display = new VectorDisplay(renderer, vMem, cpu);
	cpu->reset();
	clockCount = 0;
	tickCount = 0;
	commandTicksCount = 0;
	cycle = false;
	clock->start(this, true);
}

Vector06c::~Vector06c()
{
	tickCount = 0;
	commandTicksCount = 0;
	enabled = false;
	cycle = false;
	clock->stop();
	Sleep(1000);
	delete display;
	delete cpu;
	delete mem;
	delete clock;
}

void Vector06c::start() {
	enabled = true;
}

void Vector06c::stop() {
	enabled = false;
}